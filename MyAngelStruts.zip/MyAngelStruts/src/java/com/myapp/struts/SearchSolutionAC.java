/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.myapp.struts;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Yogi
 */
public class SearchSolutionAC extends org.apache.struts.action.Action {
    
    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
    /**
     * This is the action called from the Struts framework.
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        SolutionFormBean formbean = (SolutionFormBean) form;
        // Get the searchString from the formBean.
        String searchString = formbean.getSearchString();
        String username = (String)request.getSession().getAttribute("username");
        // Search this string in the database.
        List<SolutionFormBean> solutions = 
                searchSolution(searchString, request.getParameter("mode"), username);
        request.setAttribute("solutions", solutions);
        request.setAttribute("mode", request.getParameter("mode"));
        return mapping.findForward(SUCCESS);
    }
    public List<SolutionFormBean> searchSolution(String searchString, String mode , String username)
            throws Exception
    {
        Session session = null;
        try {
            // This step will read hibernate.cfg.xml
            // and prepare hibernate for use
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            // desc, problem and logs are properties of SolutionFormBean
            // and not the database fields.
            Criterion desc = Restrictions.like("desc", "%"+searchString+"%");
            Criterion problem = Restrictions.like("problem", "%"+searchString+"%");
            Criterion logs = Restrictions.like("logs", "%"+searchString+"%");
            List solutions = null;
            // the Disjuntion() takes single criterions and "ORs" them together.
            if(mode.equals("view"))
            {
                solutions = session.createCriteria(SolutionFormBean.class)
                    .add(Restrictions.disjunction().add(desc).add(problem).add(logs))
                    .list();
            }
            else if(mode.equals("edit"))
            {
                // This manipulates to
                // where (desc like searchString or problem like searchString
                // or logs like searchString) and (submittedby=currentuser)
                solutions = session.createCriteria(SolutionFormBean.class)
                    .add(Restrictions.disjunction().add(desc).add(problem).add(logs))
                    .add(Restrictions.eq("submittedby", username))
                    .list();
            }
            return solutions;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally{
            if(session!=null)
            {
                // Don't forget to close the session.
                session.flush();
                session.close();
            }
        }
    }

}
