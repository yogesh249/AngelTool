/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.struts;

import com.myapp.struts.addUser.UserFormBean;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Yogi
 */
public class LoginAC extends org.apache.struts.action.Action {

    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
    private static final String FAILURE = "failure";

    /**
     * This is the action called from the Struts framework.
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        LoginFormBean formbean = (LoginFormBean) form;
        String username = formbean.getUsername();
        String password = formbean.getPassword();

        List<UserFormBean> users = findUsers(username);
        if(users.size()==0)
        {
            request.setAttribute("message", "No such user exists");
            return mapping.findForward(FAILURE);
        }
        if(users.get(0).getPassword().equals(password))
        {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            return mapping.findForward(SUCCESS);
        }
        else
        {
            request.setAttribute("message", "Invalid Username/Password");
            return mapping.findForward(FAILURE);
        }


    }
    public List<UserFormBean> findUsers(String username)
            throws Exception
    {
        Session session = null;
        try {
            // This step will read hibernate.cfg.xml
            // and prepare hibernate for use
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            // username property of UserFormBean
            // and not the database fields.
            Criterion crit = Restrictions.eq("username", username );
            List users = null;
            users = session.createCriteria(UserFormBean.class)
                     .add(crit).list();
            return users;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally{
            if(session!=null)
            {
                // Don't forget to close the session.
                session.flush();
                session.close();
            }
        }
    }

}
