/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.struts;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Yogi
 */
public class SolutionAC extends DispatchAction {

    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
    private static final String SOLUTION = "solutionJSP";
    /**
     * This is the action called from the Struts framework.
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */

    public ActionForward add(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        SolutionFormBean formbean = (SolutionFormBean) form;
        boolean status = saveOrUpdate(formbean);
        if (status) {
            request.setAttribute("result", "Record inserted successfully");
        } else {
            request.setAttribute("result", "Could not insert record");
        }
        return mapping.findForward(SUCCESS);
    }
    public ActionForward view(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        // Now that we are reached the view module.
        // It is desired that it should display the values from the database
        SolutionFormBean formbean = (SolutionFormBean) form;
        SolutionFormBean dbBean = selectSolution(request.getParameter("solutionno"));

        // Fill the form bean so that the values are displayed in the JSP
        formbean.setDesc(dbBean.getDesc());
        formbean.setLogs(dbBean.getLogs());
        formbean.setProblem(dbBean.getProblem());
        formbean.setSolution(dbBean.getSolution());
        formbean.setSolutionno(dbBean.getSolutionno());
        formbean.setSubmittedby(dbBean.getSubmittedby());
        // This is required to prevent the user to edit the
        // records which he is not authorized to edit.
        String mode = (String)request.getAttribute("mode");
        if(mode==null)
        {
            mode = (String)request.getParameter("mode");
        }
        if(mode.equals("show"))
        {
            // If mode is show, that means we have come via the edit solution
            // screen.
            // Allow editing only if the username matches.
            if(formbean.getSubmittedby().equals((String)request.getSession().getAttribute("username")))
            {
                // The solution has been saved by the same user
                // which is currently logged in.
                request.setAttribute("mode", "edit");
            }
            else
            {
                // The solution has been saved by a user different
                // than the one currently logged in.
                request.setAttribute("mode", "view");
            }
        }
        else
        {
            // If mode is not there in request, then It means
            // User has reached here by Clicking View Solution.
            request.setAttribute("mode", "view");
        }
        return mapping.findForward(SOLUTION);
    }
    public ActionForward edit(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        // This is the same thing that we are doing in add mode,
        // Just that the messages are changed.
        SolutionFormBean formbean = (SolutionFormBean) form;
        boolean status = saveOrUpdate(formbean);
        if (status) {
            request.setAttribute("result", "Record updated successfully");
        } else {
            request.setAttribute("result", "Could not update the record");
        }
        return mapping.findForward(SUCCESS);
    }
    public ActionForward show(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        // Now that the display job will be done
        // We need to make sure that when the user clicks the Save button
        // It should land in the edit mode.
        // Set the mode to edit.
        // Based on the value of this attribute
        // the textboxes will be enabled or disabled in the view.
        request.setAttribute("mode", "show");
        return view(mapping, form, request, response);
    }
    private boolean saveOrUpdate(SolutionFormBean formbean) {
        Session session = null;

        //Transaction object
        // Nothing happens without transaction in hibernate.
        Transaction transaction = null;
        try {
            // This step will read hibernate.cfg.xml
            // and prepare hibernate for use
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            // Using a transaction is mandatory.
            transaction = session.beginTransaction();
            session.saveOrUpdate(formbean);
            // Commit it
            transaction.commit();
            System.out.println("Done");
            return true;
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        } finally {
            // Actual row insertion will happen at this step
            if(session!=null)
            {
                session.flush();
                session.close();
            }
            return true;
        }
    }

    private SolutionFormBean selectSolution(String solutionno) throws Exception {
        Session session = null;
        try {
            // This step will read hibernate.cfg.xml
            // and prepare hibernate for use
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            Criterion solutionnoCriterion = Restrictions.eq("solutionno", Long.parseLong(solutionno));
            List<SolutionFormBean> solutions = session.createCriteria(SolutionFormBean.class)
                    .add(solutionnoCriterion).list();
            // As we know that there will be only one solution with this number.
            return solutions.get(0);
        }
        catch(Exception e)
        {
            throw e;
        }
        finally{
            if(session!=null)
            {
                // Always remember to close the session.
                session.flush();
                session.close();
            }
        }
    }
}
