/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.myapp.struts.addUser;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Yogi
 */
public class addUserAC extends org.apache.struts.action.Action {
    
    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
    private static final String FAILURE = "failure";
    /**
     * This is the action called from the Struts framework.
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        UserFormBean userform = (UserFormBean) form;
        if(findUsers(userform.getUsername()).size()>0)
        {
            request.setAttribute("msg", "User already exists");
            return mapping.findForward(FAILURE);
        }
        if(addUser(userform))
        {
            request.setAttribute("msg", "User added successfully.");
            return mapping.findForward(SUCCESS);
        }
        else
        {
                request.setAttribute("msg", "Unable to add user.");
                return mapping.findForward(FAILURE);
        }
    }
    public boolean addUser(UserFormBean userform)
    {
        Session session = null;

        //Transaction object
        // Nothing happens without transaction in hibernate.
        Transaction transaction = null;
        try {
            // This step will read hibernate.cfg.xml
            // and prepare hibernate for use
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            // Using a transaction is mandatory.
            transaction = session.beginTransaction();
            session.saveOrUpdate(userform);
            // Commit it
            transaction.commit();
            System.out.println("Done");
            return true;
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            transaction.rollback();
            throw new ExceptionInInitializerError(ex);
        } finally {
            // Actual row insertion will happen at this step
            if(session!=null)
            {
                session.flush();
                session.close();
            }
            if(transaction.wasRolledBack())
                return false;
            else
                return true;
        }
    }
    public List<UserFormBean> findUsers(String username)
            throws Exception
    {
        Session session = null;
        try {
            // This step will read hibernate.cfg.xml
            // and prepare hibernate for use
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            session = sessionFactory.openSession();
            // username property of UserFormBean
            // and not the database fields.
            Criterion crit = Restrictions.eq("username", username );
            List users = null;
            users = session.createCriteria(UserFormBean.class)
                     .add(crit).list();
            return users;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally{
            if(session!=null)
            {
                // Don't forget to close the session.
                session.flush();
                session.close();
            }
        }
    }

}
